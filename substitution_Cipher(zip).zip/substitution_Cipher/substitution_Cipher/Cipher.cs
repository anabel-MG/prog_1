﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace substitution_Cipher
{
    public class Cipher
    {
      

      public  Cipher()
        {

            yay();
        }//end
           

        public void yay() {

            string[] alphabet = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",
            "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };

            string[] substitute = { "z", "k", "o", "t", "h", "j", "i", "f", "v",
            "n", "q", "d", "y", "g", "s", "x", "a", "m", "p", "b", "r", "w", "l", "u", "c", "e" };


            string input ;
            

            WriteLine("This is my substitution cipher ");
            WriteLine("Type something and see it get converted !");
            input = ReadLine();




            StringBuilder encryptedText = new StringBuilder();

            // Loop through each character in the input
            foreach (char letter in input)
            {
                // Check if the character is a letter
                if (char.IsLetter(letter))
                {
                    // Convert the letter to lowercase for comparison
                    char originalLetter = char.ToLower(letter);

                    // Find the index of the original letter in the alphabet
                    int index = Array.IndexOf(alphabet, originalLetter.ToString());

                    // Check if the letter is found in the alphabet
                    if (index != -1)
                    {
                        // Substitute the letter with the corresponding one from the substitute array
                        char substitutedLetter = substitute[index][0];

                        // Preserve the case of the original letter
                        if (char.IsUpper(letter))
                            substitutedLetter = char.ToUpper(substitutedLetter);

                        // Append the substituted letter to the encrypted text
                        encryptedText.Append(substitutedLetter);
                    }
                }
                else
                {
                    // Keep non-alphabetic characters unchanged and append them to the encrypted text
                    encryptedText.Append(letter);
                }
            }//end of loop

            WriteLine("Encrypted text: " + encryptedText.ToString());









            WriteLine("Press enter to exit  ");
            ReadKey();
        }//end

    }
}



