﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Store_Application
{
    public class Item
    {
        public string Name;
        public string Sale;
        public double Price;

        //constructor
        public Item()
        {

        }

        //overload constructor
        public Item(string name, string sale, double price)
        {
            Name = name;
            Sale = sale;
            Price = price;
        }

        public void About()
        {
            WriteLine($"{Name} ({Sale}) ${Price}");
        }
    }
}