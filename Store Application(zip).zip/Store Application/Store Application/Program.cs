﻿

using Store_Application;

namespace Fresh_Fruit_Market{

    class Program
    {
        static void Main()
        {
            new FruitMarket();
        }
    }
}