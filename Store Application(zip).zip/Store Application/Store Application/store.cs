﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Net.Mime.MediaTypeNames;

namespace Store_Application
{
    internal class FruitMarket
    {
        public string Name;

        //constructor
        public FruitMarket()
        {
            Open();
        }

        public void Open()
        {
            Title = "Fresh Fruit Market";
            WriteLine("Welcome to the Fresh Fruit Market\n");
            sell();
        }

        public void sell()
        {
            string input;
            int appleTotal = 0;
            int peachTotal = 0;
            int grapeTotal = 0;
            int strawberryTotal = 0;
            int orangeTotal = 0;
            int mangoTotal = 0;
            int watermelonTotal = 0;
            double total;

            Item apple = new Item("apple","this item has a spend total of 10 or more and get 4 dollars off your purchase"  ,1);
            Item peach = new Item("peach", "this item has a spend total of 10 or more and get 4 dollars off your purchase", 1);
            Item grape = new Item("grape", "this item has a spend total of 10 or more and get 4 dollars off your purchase" +
                "and a buy 2 for 1 dollar discount ", 2);
            Item strawberry = new Item("strawberry", "this item has a spend total of 10 or more and get 4 dollars off your purchase" +
                "and a buy 2 for 1 dollar discount ", 2);
            Item orange = new Item("orange", "this item has a spend total of 10 or more and get 4 dollars off your purchase" +
                "and a buy 2 for 1 dollar discount ", 2);
            Item mango = new Item("mango", "this item has a spend total of 10 or more and get 4 dollars off your purchase" +
                "and a Buy 3 get 3 for one dollar discount", 2);
            Item watermelon = new Item("watermelon", "this item has a spend total of 10 or more and get 4 dollars off your purchase" +
                "and a Buy 3 get 3 for one dollar discount", 2);

            //display
            apple.About();
            peach.About();
            grape .About();
            strawberry.About();
            orange.About();
            mango.About();
            watermelon.About();


            //sell
            WriteLine("How many " + apple.Name + " would you like?");
            input = ReadLine();
            appleTotal = Convert.ToInt32(input);

            WriteLine("How many " + peach.Name + " would you like?");
            input = ReadLine();
            peachTotal = Convert.ToInt32(input);

            WriteLine("How many " + grape.Name + " would you like?");
            input = ReadLine();
            grapeTotal = Convert.ToInt32(input);

            WriteLine("How many " + strawberry.Name + " would you like?");
            input = ReadLine();
            strawberryTotal = Convert.ToInt32(input);

            WriteLine("How many " + orange.Name + " would you like?");
            input = ReadLine();
            orangeTotal = Convert.ToInt32(input);

            WriteLine("How many " + mango.Name + " would you like?");
            input = ReadLine();
            mangoTotal = Convert.ToInt32(input);

            WriteLine("How many " + watermelon.Name + " would you like?");
            input = ReadLine();
            watermelonTotal = Convert.ToInt32(input);

          




        

            total = (appleTotal * apple.Price) + (peachTotal *peach.Price) + (grapeTotal * grape.Price
                + (strawberryTotal * strawberry.Price) + (orangeTotal * orange.Price) 
                + (mangoTotal * mango.Price) + (watermelonTotal * watermelon.Price));
            //total before discounts
            WriteLine("Total before discount is  " + total.ToString("c"));

            ;
            if ((grapeTotal == 2  || strawberryTotal == 2 || orangeTotal == 2) && ( mangoTotal==3||watermelonTotal==3) &&(total >= 10))
            {// total subtracted by 13 because instead of paying 9 dollars for  water melon or mango you pay 1 (+1), buying 2 grapes,strawberries,or oranges
             // will discount 1 dollar(-1), and if everything is more than 10 dollars you will get 4 dollars discount(-4)
             // equation would be  total - 9-4-1+1, since the 1 cancel it leaves -9-4 = -13
                total = total - 13;
            }
            else if ((mangoTotal == 3 || watermelonTotal == 3) && (total >= 10))
            {//subtract 12 because instead of paying 9(-9) dollars for  water melon or mango you pay 1(+1) 
             //and if everything is more than 10 dollars you will get 4 dollars discount(-4)
             //equation = total-9-4+1
                total = total - 12;

            }
            else if ((grapeTotal == 2 || strawberryTotal == 2) || (orangeTotal == 2 && total >= 10))
            {//subtract 5 becuase buying 2 grapes,strawberries,or oranges will discount 1 dollar(-1)
             //and if everything is more than 10 dollars you will get 4 dollars discount(-4)
             //total- 4-1 equals total-5
                total = total - 5; 

            }
            else if ((grapeTotal == 2 || strawberryTotal == 2 || orangeTotal == 2) && (mangoTotal == 3 || watermelonTotal == 3))
            {//subtract 9 because instead of paying 9 dollars for  water melon or mango you pay 1 (+1) 
             // and strawberries,or oranges will discount 1 dollar(-1)
             //total=9-1+1=  total - 9;
                total = total - 9;
            }
            else if (grapeTotal == 2 || strawberryTotal == 2 || orangeTotal == 2)
            {//subtract 1 because strawberries,or oranges will discount 1 dollar(-1)
                total = total - 1; 
            }
            else if (mangoTotal == 3 || watermelonTotal == 3)
            {//subtract 8 because instead of paying 9 dollars for  water melon or mango you pay 1 (+1)
                //total-9+1 = total - 8
                total = total - 8; 
            }
            
            
            else if (total >= 10)
            {//subtract because  everything is 10 or is  more than 10 dollars you will get 4 dollars discount(-4)
                total = total - 4; 
            }
            else
            {
                WriteLine("no discounts today ");
            }


            //total  after discounts
            WriteLine("Total after discount is  " + total.ToString("c"));

            ReadKey();
        }
    }
}