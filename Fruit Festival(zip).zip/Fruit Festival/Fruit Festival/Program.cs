﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace hello_World
{
    class Program
    {
        static void Main(string[] args)

        {
            new play();
        }
    }



    public class play
    {

        public play()
        {
            StartGame();
        }
        //character strings for the game
        public string character1 = "Apple";
        public string character2 = "Berry";
        public string character3 = "Orange";
        public string character4 = "Banana";
        public string character5 = "Mango";
        public string character6 = "Peach";
        public string character7 = "Cherry";
        public string input;
        public int choice;
        public int userChoice; // Use a separate variable to store user input //DONT DELETE
        public int finalChoice;

        //makes a slow type effect
        static void TypeLine(string value)
        {
            Thread.Sleep(1000);
            foreach (var letter in value)
            {
                Write(letter);
                Thread.Sleep(60);
            }
            WriteLine();
        }
        //game intro
        public void StartGame()
        {


            Title = "The Fruit Festival";
            TypeLine("Welcome to the Fruit festival!");
            TypeLine("Meet our fruit friends");
            TypeLine("    ");
            TypeLine(character1 + " (Your character)");
            TypeLine(character7);


            TypeLine(character3);

            TypeLine(character4);

            TypeLine(character5);

            TypeLine(character6);

            TypeLine("And....");
            TypeLine(character2 + "!");
            TypeLine(" ");
            TypeLine("The fruit friends are preparing for the fruit festival");
            TypeLine("Lets go help them ");





            Game();

        }


        //game starts
        public void Game()
        {

            TypeLine("...");
            WriteLine("[You walk into the meeting room where you see see the notes from yesterdays meeting]");
            TypeLine("[Apple:Supervisor]");
            TypeLine("[Cherry and Mango:party decorations]");
            TypeLine("[Berry and Peach:cake]");
            TypeLine("[Orange and Banana:fireworks]");
            TypeLine(" "); TypeLine(" ");
            TypeLine(" ''That's right i have to help my friends'' [you think to yourself] ");
            TypeLine(" ");
            TypeLine("Who will you help first?");

            TypeLine("1.)Cherry and Mango");
            TypeLine("2.)Berry and Peach");
            TypeLine("3.)Orange and Banana");
            WriteLine(" ");



            //diologue plays based on the player choice 
            // a loop that repeats until the player inputs a valid answer
            do
            {
                TypeLine("Enter a number (1, 2, or 3): ");
                string theFirstInput = ReadLine();
                //depending on the choice,1,2,or 3, the diologue will play, only these choices will work , "Invalid input. Please enter 1, 2, or 3." will be displayed 
                if (int.TryParse(theFirstInput, out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            TypeLine("Let's go help Cherry and Mango first");
                            break;
                        case 2:
                            TypeLine("Let's go help Berry and Peach first");
                            break;
                        case 3:
                            TypeLine("Let's go help Orange and Banana first");
                            break;
                        default:
                            WriteLine("Invalid input. Please enter 1, 2, or 3.");
                            break;
                    }
                }
                else
                {
                    WriteLine("Invalid input. Please enter a valid number.");
                }
            } while (choice < 1 || choice > 3);
            // depending on the player choice from the previous event, these will play 

            if (choice == 1)
            {
                TypeLine(" ");
                TypeLine("...");
                TypeLine("You make your way to Mango's house to help with the party decorations ");
                TypeLine("...");
                WriteLine("[Arriving at Mango's House] ");
                TypeLine(" ");
                WriteLine("Mango:");
                TypeLine("''Hi Apple,Glad too see you ''");
                WriteLine("Cherry:");
                TypeLine("''Hi Apple! ''");
                WriteLine("Cherry:");
                TypeLine("''We were actaully need your help with something ''");
                WriteLine("Mango:");
                TypeLine("''We're trying to decide which color to make the decorations, i was thinking of yellow- ''");
                WriteLine("Cherry:");
                TypeLine("''But i was thinking of red-  ''");
                WriteLine("Mango:");
                TypeLine("''Can you help us decide? ''");
                WriteLine("[Which color should they pick?:");
                WriteLine("[a)yellow,b)red,c)Both");


                TypeLine("Enter a letter (a, b, or c): ");
                string thenextInput = ReadLine();
                //depending on the choice,1,2,or 3, the diologue will play, only these choices will work , "Invalid input. Please enter 1, 2, or 3." will be displayed 

                if (thenextInput == "a")
                {
                    WriteLine("Apple:");
                    TypeLine("Let's choose red!");
                    TypeLine(" ");
                    WriteLine("Cherry:");
                    TypeLine("''Yay my favorite. ''");
                    WriteLine("Mango:");
                    TypeLine("''Thanks for your help apple!. ''");

                }
                else if (thenextInput == "b")
                {
                    WriteLine("Apple:");
                    TypeLine("Let's choose yellow!");
                    TypeLine(" ");
                    WriteLine("Mango:");
                    TypeLine("''Lovely.  ''");
                    WriteLine("Cherry:");
                    TypeLine("''Thanks for your help apple!. ''");


                }
                else if (thenextInput == "c")
                {
                    WriteLine("Apple:");
                    TypeLine("Why not both!");
                    TypeLine(" ");
                    WriteLine("Cherry and Mango:");
                    TypeLine("''What a good idea , thanks for your help! ''");


                }







            }
            else if (choice == 2)
            {
                TypeLine(" ");
                TypeLine("...");
                TypeLine("You make your way to Peach's bakery to help with the cake ");
                TypeLine("...");
                WriteLine("[Arriving at Peach's bakery] ");
                TypeLine("[As you walk in the bakery the a sweet smell comes to you] ");
                TypeLine("[You spot your friends berry and peach, you walk over to them]");
                TypeLine(" ");
                WriteLine("Peach:");
                TypeLine("''Hi apple''");
                WriteLine("Berry:");
                TypeLine("[waves at you]");
                WriteLine("Apple:");
                TypeLine("''Hi , do you need help with anything?''");
                WriteLine("Peach:");
                TypeLine("''Yea we actually need help finding some ingredients,can you help us?''");
                WriteLine("Apple:");
                TypeLine("''Sure!''");
                TypeLine(" ");
                TypeLine("[You head over to the fridge to find the nessesary ingredients]");
                TypeLine("[You spot a note left by berry],''Complete the shape to find ingredients''");
                TypeLine("...");




                while (true) // Infinite loop until correct input is provided
                {
                    TypeLine("Finish this shape: [ ");
                    string matchShape1 = ReadLine();

                    if (matchShape1 == "]")
                    {
                        TypeLine("[]");
                        TypeLine("Correct");


                        break; // Exit the loop since correct shape entered
                    }
                    else
                    {
                        TypeLine("Oops...Try again ");
                    }
                }

                TypeLine("[Great!]");
                TypeLine("...");

                while (true) // Infinite loop until correct input is provided
                {
                    TypeLine("Finish this shape: ( ");
                    string matchShape2 = ReadLine();

                    if (matchShape2 == ")")
                    {
                        TypeLine("()");
                        TypeLine("Correct");


                        break; // Exit the loop since correct shape entered
                    }
                    else
                    {
                        TypeLine("Oops...Try again ");
                    }
                }

                TypeLine("[Nice!]");
                TypeLine("...");

                while (true) // Infinite loop until correct input is provided
                {
                    TypeLine("Finish this shape: < ");
                    string matchShape2 = ReadLine();

                    if (matchShape2 == ">")
                    {
                        TypeLine("<>");
                        TypeLine("Correct");


                        break; // Exit the loop since correct shape entered
                    }
                    else
                    {
                        TypeLine("Oops...Try again ");
                    }
                }
                TypeLine(" ");
                TypeLine("[Heading back to the kitchen");
                WriteLine("Peach:");
                TypeLine("''Thanks for finding the ingredients apple !''");
                WriteLine("Berry:");
                TypeLine("[nods and smiles]");
















            }
            else if (choice == 3)
            {
                TypeLine(" ");
                TypeLine("...");
                TypeLine("You make your way to Banana's workshop to help with the fireworks ");
                TypeLine("...");
                WriteLine("[Arriving at Banana's workshop] ");
                TypeLine("...");
                WriteLine("BOOOOM");
                TypeLine("[You hear an explosion coming towards Banana's workshop ]");
                TypeLine("[Inside the workshop]");
                WriteLine("Apple:");
                TypeLine("Are you guys alright!?");
                WriteLine("Banana:");
                TypeLine("Yup we were just testing a few of these fireworks");
                WriteLine("Orange:");
                TypeLine("There's a bit of a problem though, see we had a couple of fire work stored away in this box");
                TypeLine("[Orange shows you a box]");
                WriteLine("Orange:");
                TypeLine("But banana forgot the passcode");
                WriteLine("Banana:");
                TypeLine("....");
                TypeLine("OOps");
                WriteLine("Orange:");
                TypeLine("I've been trying to guess the passcode but had no luck");
                WriteLine("Banana:");
                TypeLine("Ok all i know is the first number might probably maybe 5");
                WriteLine("Orange:");
                TypeLine("Wish you remember the rest....");
                WriteLine("Orange:");
                TypeLine("Anyways, Can you have a go at it Apple ?");
                WriteLine(" ");
                WriteLine("Apple:");
                TypeLine("Sure I can try ");
                TypeLine("   ");
                TypeLine("...");
                TypeLine("[The box has three slots, the first number is likely 5 but you'll have to guess the other two, the numbers only go from 0-9  ]");



                int[] combination = { 5, 9, 0 };

                bool chestUnlocked = false;

                // Loop until the box is unlocked
                while (!chestUnlocked)
                {
                    int[] guess = new int[3];

                    // Player enters each digit of the combination one by one
                    for (int i = 0; i < combination.Length; i++)
                    {
                        Write($"Enter digit {i + 1} of the combination (0-9): ");
                        if (!int.TryParse(ReadLine(), out guess[i]) || guess[i] < 0 || guess[i] > 9)
                        {
                            WriteLine("Invalid input. Please enter a number between 0 and 9.");
                            break;
                        }
                    }

                    // Check combination
                    if (CheckCombination(guess, combination))
                    {
                        WriteLine("Hooray! You opened the box!");
                        chestUnlocked = true;
                    }
                    else
                    {
                        WriteLine("That doesn't seem to be it, let's try again.");
                    }
                }

                // Function to check if the guess matches the combination
                static bool CheckCombination(int[] guess, int[] combination)
                {
                    for (int i = 0; i < guess.Length; i++)
                    {
                        if (guess[i] != combination[i])
                        {
                            return false;
                        }
                    }
                    return true;
                }

                WriteLine("Banana:");
                TypeLine("WOW you actually opened it apple!");
                WriteLine("Orange:");
                TypeLine("YES, Thanks a lot apple !");

                WriteLine("Apple:");
                TypeLine("No probelm");

            }




            ///////////////////////////////////////////////////////////////////////////////////////////////////





            TypeLine(" ");
            TypeLine("...");
            TypeLine("[After finishing with your task you head to the next location,who will you help? ");
            TypeLine("...");




            if (choice == 1)
            {
                do
                {
                    TypeLine("Enter a number (2, or 3): ");
                    string theFirstSecondInput = ReadLine();

                    if (int.TryParse(theFirstSecondInput, out userChoice)) // Use userChoice variable here
                    {
                        switch (userChoice)
                        {
                            case 2:
                                TypeLine("Let's go help Berry and Peach next");
                                break;
                            case 3:
                                TypeLine("Let's go help Orange and Banana next");
                                break;
                            default:
                                WriteLine("Invalid input. Please enter 2 or 3.");
                                break;
                        }
                    }
                    else
                    {
                        WriteLine("Invalid input. Please enter a valid number.");
                    }
                    break;
                } while (userChoice != 2 && userChoice != 3); // Check userChoice here
            }
            else if (choice == 2)
            {
                do
                {
                    TypeLine("Enter a number (1, or 3): ");
                    string theSecondSecondInput = ReadLine(); // Use a different variable for user input

                    if (int.TryParse(theSecondSecondInput, out userChoice)) // Use a different variable here
                    {
                        switch (userChoice)
                        {
                            case 1:
                                TypeLine("Let's go help Cherry and Mango next");
                                break;
                            case 3:
                                TypeLine("Let's go help Orange and Banana next");
                                break;
                            default:
                                WriteLine("Invalid input. Please enter 1 or 3.");
                                break;
                        }
                    }
                    else
                    {
                        WriteLine("Invalid input. Please enter a valid number.");
                    }
                    break;
                } while (userChoice != 1 && userChoice != 3); // Check userChoice here
            }
            else if (choice == 3)
            {
                do
                {
                    TypeLine("Enter a number (1, or 2): ");
                    string theThirdSecondInput = ReadLine(); // Use a different variable for user input

                    if (int.TryParse(theThirdSecondInput, out userChoice)) // Use a different variable here
                    {
                        switch (userChoice)
                        {
                            case 1:
                                TypeLine("Let's go help Cherry and Mango next");



                                break;
                            case 2:
                                TypeLine("Let's go help Berry and Peach next");
                                break;
                            default:
                                WriteLine("Invalid input. Please enter 1 or 2.");
                                break;
                        }
                    }
                    else
                    {
                        WriteLine("Invalid input. Please enter a valid number.");
                    }
                    break;
                } while (userChoice != 1 && userChoice != 2); // Check userChoice here
            }

            //second event based on previous answers





            if (userChoice == 1)
            {
                do
                {

                    TypeLine(" ");
                    TypeLine("...");
                    TypeLine("You make your way to Mango's house to help with the party decorations ");
                    TypeLine("...");
                    WriteLine("[Arriving at Mango's House] ");
                    TypeLine(" ");
                    WriteLine("Mango:");
                    TypeLine("''Hi Apple,Glad too see you ''");
                    WriteLine("Cherry:");
                    TypeLine("''Hi Apple! ''");
                    WriteLine("Cherry:");
                    TypeLine("''We were actaully need your help with something ''");
                    WriteLine("Mango:");
                    TypeLine("''We're trying to decide which color to make the decorations, i was thinking of yellow- ''");
                    WriteLine("Cherry:");
                    TypeLine("''But i was thinking of red-  ''");
                    WriteLine("Mango:");
                    TypeLine("''Can you help us decide? ''");
                    WriteLine("[Which color should they pick?:");
                    WriteLine("[a)yellow,b)red,c)Both");


                    TypeLine("Enter a letter (a, b, or c): ");
                    string thenextInput = ReadLine();
                    //depending on the choice,1,2,or 3, the diologue will play, only these choices will work , "Invalid input. Please enter 1, 2, or 3." will be displayed 

                    if (thenextInput == "a")
                    {
                        WriteLine("Apple:");
                        TypeLine("Let's choose red!");
                        TypeLine(" ");
                        WriteLine("Cherry:");
                        TypeLine("''Yay my favorite. ''");
                        WriteLine("Mango:");
                        TypeLine("''Thanks for your help apple!. ''");

                    }
                    else if (thenextInput == "b")
                    {
                        WriteLine("Apple:");
                        TypeLine("Let's choose yellow!");
                        TypeLine(" ");
                        WriteLine("Mango:");
                        TypeLine("''Lovely.  ''");
                        WriteLine("Cherry:");
                        TypeLine("''Thanks for your help apple!. ''");


                    }
                    else if (thenextInput == "c")
                    {
                        WriteLine("Apple:");
                        TypeLine("Why not both!");
                        TypeLine(" ");
                        WriteLine("Cherry and Mango:");
                        TypeLine("''What a good idea , thanks for your help! ''");


                    }

                    break;
                } while (userChoice != 2 && userChoice != 3); // Check userChoice here




            }
            else if (userChoice == 2)
            {

                do
                {
                    TypeLine(" ");
                    TypeLine("...");
                    TypeLine("You make your way to Peach's bakery to help with the cake ");
                    TypeLine("...");
                    WriteLine("[Arriving at Peach's bakery] ");
                    TypeLine("[As you walk in the bakery the a sweet smell comes to you] ");
                    TypeLine("[You spot your friends berry and peach, you walk over to them]");
                    TypeLine(" ");
                    WriteLine("Peach:");
                    TypeLine("''Hi apple''");
                    WriteLine("Berry:");
                    TypeLine("[waves at you]");
                    WriteLine("Apple:");
                    TypeLine("''Hi , do you need help with anything?''");
                    WriteLine("Peach:");
                    TypeLine("''Yea we actually need help finding some ingredients,can you help us?''");
                    WriteLine("Apple:");
                    TypeLine("''Sure!''");
                    TypeLine(" ");
                    TypeLine("[You head over to the fridge to find the nessesary ingredients]");
                    TypeLine("[You spot a note left by berry],''Complete the shape to find ingredients''");
                    TypeLine("...");




                    while (true) // Infinite loop until correct input is provided
                    {
                        TypeLine("Finish this shape: [ ");
                        string matchShape1 = ReadLine();

                        if (matchShape1 == "]")
                        {
                            TypeLine("[]");
                            TypeLine("Correct");


                            break; // Exit the loop since correct shape entered
                        }
                        else
                        {
                            TypeLine("Oops...Try again ");
                        }
                    }

                    TypeLine("[Great!]");
                    TypeLine("...");

                    while (true) // Infinite loop until correct input is provided
                    {
                        TypeLine("Finish this shape: ( ");
                        string matchShape2 = ReadLine();

                        if (matchShape2 == ")")
                        {
                            TypeLine("()");
                            TypeLine("Correct");


                            break; // Exit the loop since correct shape entered
                        }
                        else
                        {
                            TypeLine("Oops...Try again ");
                        }
                    }

                    TypeLine("[Nice!]");
                    TypeLine("...");

                    while (true) // Infinite loop until correct input is provided
                    {
                        TypeLine("Finish this shape: < ");
                        string matchShape2 = ReadLine();

                        if (matchShape2 == ">")
                        {
                            TypeLine("<>");
                            TypeLine("Correct");


                            break; // Exit the loop since correct shape entered
                        }
                        else
                        {
                            TypeLine("Oops...Try again ");
                        }
                    }
                    TypeLine(" ");
                    TypeLine("[Heading back to the kitchen");
                    WriteLine("Peach:");
                    TypeLine("''Thanks for finding the ingredients apple !''");
                    WriteLine("Berry:");
                    TypeLine("[nods and smiles]");
                    break;
                } while (userChoice != 1 && userChoice != 3); // Check userChoice here
              













            }

            else if (userChoice == 3)
            {

                do
                {
                    TypeLine(" ");
                    TypeLine("...");
                    TypeLine("You make your way to Banana's workshop to help with the fireworks ");
                    TypeLine("...");
                    WriteLine("[Arriving at Banana's workshop] ");
                    TypeLine("...");
                    WriteLine("BOOOOM");
                    TypeLine("[You hear an explosion coming towards Banana's workshop ]");
                    TypeLine("[Inside the workshop]");
                    WriteLine("Apple:");
                    TypeLine("Are you guys alright!?");
                    WriteLine("Banana:");
                    TypeLine("Yup we were just testing a few of these fireworks");
                    WriteLine("Orange:");
                    TypeLine("There's a bit of a problem though, see we had a couple of fire work stored away in this box");
                    TypeLine("[Orange shows you a box]");
                    WriteLine("Orange:");
                    TypeLine("But banana forgot the passcode");
                    WriteLine("Banana:");
                    TypeLine("....");
                    TypeLine("OOps");
                    WriteLine("Orange:");
                    TypeLine("I've been trying to guess the passcode but had no luck");
                    WriteLine("Banana:");
                    TypeLine("Ok all i know is the first number might probably maybe 5");
                    WriteLine("Orange:");
                    TypeLine("Wish you remember the rest....");
                    WriteLine("Orange:");
                    TypeLine("Anyways, Can you have a go at it Apple ?");
                    WriteLine(" ");
                    WriteLine("Apple:");
                    TypeLine("Sure I can try ");
                    TypeLine("   ");
                    TypeLine("...");
                    TypeLine("[The box has three slots, the first number is likely 5 but you'll have to guess the other two, the numbers only go from 0-9  ]");



                    int[] combination = { 5, 9, 0 };

                    bool chestUnlocked = false;

                    // Loop until the box is unlocked
                    while (!chestUnlocked)
                    {
                        int[] guess = new int[3];

                        // Player enters each digit of the combination one by one
                        for (int i = 0; i < combination.Length; i++)
                        {
                            Write($"Enter digit {i + 1} of the combination (0-9): ");
                            if (!int.TryParse(ReadLine(), out guess[i]) || guess[i] < 0 || guess[i] > 9)
                            {
                                WriteLine("Invalid input. Please enter a number between 0 and 9.");
                                break;
                            }
                        }

                        // Check combination
                        if (CheckCombination(guess, combination))
                        {
                            WriteLine("Hooray! You opened the box!");
                            chestUnlocked = true;
                        }
                        else
                        {
                            WriteLine("That doesn't seem to be it, let's try again.");
                        }
                    }

                    // Function to check if the guess matches the combination
                    static bool CheckCombination(int[] guess, int[] combination)
                    {
                        for (int i = 0; i < guess.Length; i++)
                        {
                            if (guess[i] != combination[i])
                            {
                                return false;
                            }
                        }
                        return true;
                    }

                    WriteLine("Banana:");
                    TypeLine("WOW you actually opened it apple!");
                    WriteLine("Orange:");
                    TypeLine("YES, Thanks a lot apple !");

                    WriteLine("Apple:");
                    TypeLine("No probelm");


                    break;
                } while (userChoice != 2 && userChoice != 1); // Check userChoice here
            }











                //*******************************************************************************************************************
                //*******************************************************************************************************************

                //*******************************************************************************************************************

                //*******************************************************************************************************************

                TypeLine(" ");
                TypeLine("...");
                TypeLine("[Now lets head to the last location] ");
                TypeLine("...");




                if (choice == 1 && userChoice == 2  || choice == 1 && userChoice == 3   )

                {
                   


                    
                        TypeLine("Let's go help Orange and Banana ");
                TypeLine(" ");
                TypeLine("...");
                TypeLine("You make your way to Banana's workshop to help with the fireworks ");
                TypeLine("...");
                WriteLine("[Arriving at Banana's workshop] ");
                TypeLine("...");
                WriteLine("BOOOOM");
                TypeLine("[You hear an explosion coming towards Banana's workshop ]");
                TypeLine("[Inside the workshop]");
                WriteLine("Apple:");
                TypeLine("Are you guys alright!?");
                WriteLine("Banana:");
                TypeLine("Yup we were just testing a few of these fireworks");
                WriteLine("Orange:");
                TypeLine("There's a bit of a problem though, see we had a couple of fire work stored away in this box");
                TypeLine("[Orange shows you a box]");
                WriteLine("Orange:");
                TypeLine("But banana forgot the passcode");
                WriteLine("Banana:");
                TypeLine("....");
                TypeLine("OOps");
                WriteLine("Orange:");
                TypeLine("I've been trying to guess the passcode but had no luck");
                WriteLine("Banana:");
                TypeLine("Ok all i know is the first number might probably maybe 5");
                WriteLine("Orange:");
                TypeLine("Wish you remember the rest....");
                WriteLine("Orange:");
                TypeLine("Anyways, Can you have a go at it Apple ?");
                WriteLine(" ");
                WriteLine("Apple:");
                TypeLine("Sure I can try ");
                TypeLine("   ");
                TypeLine("...");
                TypeLine("[The box has three slots, the first number is likely 5 but you'll have to guess the other two, the numbers only go from 0-9  ]");



                int[] combination = { 5, 9, 0 };

                bool chestUnlocked = false;

                // Loop until the box is unlocked
                while (!chestUnlocked)
                {
                    int[] guess = new int[3];

                    // Player enters each digit of the combination one by one
                    for (int i = 0; i < combination.Length; i++)
                    {
                        Write($"Enter digit {i + 1} of the combination (0-9): ");
                        if (!int.TryParse(ReadLine(), out guess[i]) || guess[i] < 0 || guess[i] > 9)
                        {
                            WriteLine("Invalid input. Please enter a number between 0 and 9.");
                            break;
                        }
                    }

                    // Check combination
                    if (CheckCombination(guess, combination))
                    {
                        WriteLine("Hooray! You opened the box!");
                        chestUnlocked = true;
                    }
                    else
                    {
                        WriteLine("That doesn't seem to be it, let's try again.");
                    }
                }

                // Function to check if the guess matches the combination
                static bool CheckCombination(int[] guess, int[] combination)
                {
                    for (int i = 0; i < guess.Length; i++)
                    {
                        if (guess[i] != combination[i])
                        {
                            return false;
                        }
                    }
                    return true;
                }

                WriteLine("Banana:");
                TypeLine("WOW you actually opened it apple!");
                WriteLine("Orange:");
                TypeLine("YES, Thanks a lot apple !");

                WriteLine("Apple:");
                TypeLine("No probelm");




            }
            else if (choice == 2 && userChoice == 3 || choice == 2 && userChoice == 1)
                {
                    TypeLine("Let's go help Cherry and Mango ");


                    TypeLine(" ");
                    TypeLine("...");
                    TypeLine("You make your way to Mango's house to help with the party decorations ");
                    TypeLine("...");
                    WriteLine("[Arriving at Mango's House] ");
                    TypeLine(" ");
                    WriteLine("Mango:");
                    TypeLine("''Hi Apple,Glad too see you ''");
                    WriteLine("Cherry:");
                    TypeLine("''Hi Apple! ''");
                    WriteLine("Cherry:");
                    TypeLine("''We were actaully need your help with something ''");
                    WriteLine("Mango:");
                    TypeLine("''We're trying to decide which color to make the decorations, i was thinking of yellow- ''");
                    WriteLine("Cherry:");
                    TypeLine("''But i was thinking of red-  ''");
                    WriteLine("Mango:");
                    TypeLine("''Can you help us decide? ''");
                    WriteLine("[Which color should they pick?:");
                    WriteLine("[a)yellow,b)red,c)Both");


                    TypeLine("Enter a letter (a, b, or c): ");
                    string thenextInput = ReadLine();
                    //depending on the choice,1,2,or 3, the diologue will play, only these choices will work , "Invalid input. Please enter 1, 2, or 3." will be displayed 

                    if (thenextInput == "a")
                    {
                        WriteLine("Apple:");
                        TypeLine("Let's choose red!");
                        TypeLine(" ");
                        WriteLine("Cherry:");
                        TypeLine("''Yay my favorite. ''");
                        WriteLine("Mango:");
                        TypeLine("''Thanks for your help apple!. ''");

                    }
                    else if (thenextInput == "b")
                    {
                        WriteLine("Apple:");
                        TypeLine("Let's choose yellow!");
                        TypeLine(" ");
                        WriteLine("Mango:");
                        TypeLine("''Lovely.  ''");
                        WriteLine("Cherry:");
                        TypeLine("''Thanks for your help apple!. ''");


                    }
                    else if (thenextInput == "c")
                    {
                        WriteLine("Apple:");
                        TypeLine("Why not both!");
                        TypeLine(" ");
                        WriteLine("Cherry and Mango:");
                        TypeLine("''What a good idea , thanks for your help! ''");


                    }

                }
                else if (choice == 3 && userChoice == 1 || choice == 3 && userChoice == 2)
            {
                    TypeLine("Let's go help Berry and Peach ");

                    TypeLine(" ");
                    TypeLine("...");
                    TypeLine("You make your way to Peach's bakery to help with the cake ");
                    TypeLine("...");
                    WriteLine("[Arriving at Peach's bakery] ");
                    TypeLine("[As you walk in the bakery the a sweet smell comes to you] ");
                    TypeLine("[You spot your friends berry and peach, you walk over to them]");
                    TypeLine(" ");
                    WriteLine("Peach:");
                    TypeLine("''Hi apple''");
                    WriteLine("Berry:");
                    TypeLine("[waves at you]");
                    WriteLine("Apple:");
                    TypeLine("''Hi , do you need help with anything?''");
                    WriteLine("Peach:");
                    TypeLine("''Yea we actually need help finding some ingredients,can you help us?''");
                    WriteLine("Apple:");
                    TypeLine("''Sure!''");
                    TypeLine(" ");
                    TypeLine("[You head over to the fridge to find the nessesary ingredients]");
                    TypeLine("[You spot a note left by berry],''Complete the shape to find ingredients''");
                    TypeLine("...");




                    while (true) // Infinite loop until correct input is provided
                    {
                        TypeLine("Finish this shape: [ ");
                        string matchShape1 = ReadLine();

                        if (matchShape1 == "]")
                        {
                            TypeLine("[]");
                            TypeLine("Correct");


                            break; // Exit the loop since correct shape entered
                        }
                        else
                        {
                            TypeLine("Oops...Try again ");
                        }
                    }

                    TypeLine("[Great!]");
                    TypeLine("...");

                    while (true) // Infinite loop until correct input is provided
                    {
                        TypeLine("Finish this shape: ( ");
                        string matchShape2 = ReadLine();

                        if (matchShape2 == ")")
                        {
                            TypeLine("()");
                            TypeLine("Correct");


                            break; // Exit the loop since correct shape entered
                        }
                        else
                        {
                            TypeLine("Oops...Try again ");
                        }
                    }

                    TypeLine("[Nice!]");
                    TypeLine("...");

                    while (true) // Infinite loop until correct input is provided
                    {
                        TypeLine("Finish this shape: < ");
                        string matchShape2 = ReadLine();

                        if (matchShape2 == ">")
                        {
                            TypeLine("<>");
                            TypeLine("Correct");


                            break; // Exit the loop since correct shape entered
                        }
                        else
                        {
                            TypeLine("Oops...Try again ");
                        }
                    }
                    TypeLine(" ");
                    TypeLine("[Heading back to the kitchen");
                    WriteLine("Peach:");
                    TypeLine("''Thanks for finding the ingredients apple !''");
                    WriteLine("Berry:");
                    TypeLine("[nods and smiles]");




                }



              

                TypeLine("[After helping your friends prepare for the festival you head home to rest and get ready to party tommorow");
                TypeLine("    ");
                TypeLine(".....");
                TypeLine("    ");

                TypeLine("{THE NEXT DAY]    ");

                TypeLine(" [You suit up for the day and get yourself ready for the festival]   ");
                TypeLine(".....");
                TypeLine("[After getting ready you head to the fruitfestival]    ");
                TypeLine(".....");
                TypeLine("[You meet up with your friends to party  ]");
                TypeLine("[Have fun! Enjoy the fruit festival]");

                TypeLine("    ");
                TypeLine("    ");
                TypeLine("    ");
                TypeLine("    ");
                TypeLine("    ");
                WriteLine("Thanks for playing :)");
            WriteLine("Press Enter to exit");




















            ReadKey();










            

        }
    }
}

 




       
   
       

    








  






