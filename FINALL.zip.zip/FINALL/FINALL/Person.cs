﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINALL
{
    internal class Person
    {
        public string Name = "Annonymous Player";
        public List<Item> Inventory= new List<Item>();
        public int dollar = 10;


        public Person() 
        {

            Inventory.Add(new Item("String","Some string to start forming your bracelet "));

        }

        public string ShowInventory() 
        
        {
            string output = "Inventory:" + "\n";
        foreach(Item i in Inventory) 
            {
                output += i.ItemName + "\n" ;
            
            }
        return output;
        }

        public string ShowInformation()
        {

            return $"Dollar: {dollar}\n";



        }






    }
}
