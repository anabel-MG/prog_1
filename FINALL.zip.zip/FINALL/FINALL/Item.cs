﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINALL
{
    internal class Item
    {

        public string ItemName;
        public string ItemDescription;  

        public Item(string name, string description) 
        
        { 
        ItemName = name;
        ItemDescription = description;
        }



    }
}
