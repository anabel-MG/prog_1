﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace FINALL
{
     class Location
    {

        public string Name;
        public string Description;
        public string LocationPath = "Images/welcome-screen.jpg";
        public List<Item> Items = new List<Item>();

        public Location() { }
        public Location(string name, string description)
        {
            Name = name;
            Description = description;

        }//closes public Location(string name, string description)


        public Location(string name, string description, string locationpath)
        {
            Name = name;
            Description = description;
            LocationPath = locationpath;

        }//closes public Location(string name, string description)


        public Location(string name, string description, string locationpath,List<Item> items)
        {
            Name = name;
            Description = description;
            LocationPath = locationpath;
            Items = items;

        }







        public BitmapImage ShowLocationImage()
        {
            return new BitmapImage(new Uri(LocationPath, UriKind.Relative));
        }












    }//ends class location
}//ends namespace finall
