﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FINALL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>





    public partial class MainWindow : Window
    {
        List<Location> locations = new List<Location>();
        Location currentLocation;
        Person player = new Person();
        Random randomNumber = new Random();
        Item currentItem = new Item("","");

        public MainWindow()
        {
            InitializeComponent();
        }//closes public MainWindow


        //set up locations


        private void Start()
        {
            SetupLocations();
            ShowLocationsMenu();
            Travel();
            LocationSpecificAction();
        }

        private void UpdatePlayerInformation() 
        
        {
            PlayerName.Content = player.Name;
            PlayerInventoryTextBox.Text = player.ShowInventory();
            PlayerInformation.Text = player.ShowInformation();  
        }

        private void Travel()
        {

            LocationName.Text = currentLocation.Name;
            LocationDescription.Text = currentLocation.Description;
            LocationImageBox.Source = currentLocation.ShowLocationImage();
            TravelTB.Text = "";
            UpdatePlayerInformation();


        }


        private void LocationSpecificAction() 
        
        {
            //random item show up \
            if (currentLocation.Items.Count > 0)
            {
                currentItem = currentLocation.Items[GetRandomNumber(currentLocation.Items.Count)];
                LocSpecTextbox.Text = $"You have found...  {currentItem.ItemName}{(currentItem.ItemDescription)}.\n  would you like to keep this item," +
                    $" type yes if you would like to add it , ";
            }
           else
            {
                LocSpecTextbox.Text = "You have enough items from this location, travel elsewhere to get more items ";

            }


        }

        private int GetRandomNumber(int max)

        {

            return randomNumber.Next(max);

        }




        private void SetupLocations()
        {
           
            locations.Add
                (new Location
                ("Bead Shop", 
                "Get the beads for your bracelet",
                "Images/beads.png",
                new List<Item>
                {
                    new Item("plain beads", " common type of beads "),
                    new Item("Colorful beads"," common type of beads "),
                     new Item("Glitter beads"," rare type of beads "),
                     new Item("Metallic  beads"," rare type of beads "),
                     new Item("Glass  beads"," Ultra rare type of beads")

                }//close list
                
                ));


            locations.Add
                (new Location("Charms Shop","Get charms to decorate your bracelet","Images/charm.png",

                new List<Item>
                {
                    new Item("plain charms", " common type of charms "),
                    new Item("Shape charms"," common type of charms "),
                     new Item("Pearl charms "," rare type of charms "),
                     new Item("Clay charms"," rare type of charms "),
                     new Item("Metal charms"," Ultra rare type of charms "),

                }//close list

                ));

            locations.Add
                (new Location("Trading Station", "Trade for other items", "Images/dog-trade.png",

                new List<Item>
                {
                    new Item("Common bead", " common type of item "),
                      new Item("Rare beads"," rare type of item "),
                      new Item("Ultra rare  beads"," Ultra rare type of item"),
                    new Item("Common charms"," common type of item "),
                     new Item("Rare charms "," rare type of item "),
                     new Item("Ultra rare charms"," Ultra rare type of item ")

                }

                ));



            locations.Add(new Location("Selling Station", "Sell bracelts", "Images/selling-item.png",


                new List<Item>
                {
                    new Item("Sell Common Item", " common type of item earns $1 "),
                      new Item(" Sell Rare item "," rare type of item earns $3 "),
                      new Item("Sell Ultra rare  item"," Ultra rare type of item earns $5")
                   
                }



                ));




            currentLocation = locations[0];


        }// close set up loct

        private void ShowLocationsMenu()
        {
            string temp = "";
            foreach (Location location in locations)

            {
                temp += location.Name + "\n";
            }
            LocationMenu.Text = temp;

        }//menu locations 


        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //did they enter text for textb
            string location = TravelTB.Text;
            location = location.ToLower();

            if (location != "")
            {
                foreach (Location l in locations)

                {
                    if (l.Name.ToLower().Contains(location))
                    {

                        currentLocation = l;
                        Travel();

                    }


                }//foreach (Location l in locations)

            }//if (location != "")

        }//button click

        private void MainGrid_Loaded(object sender, RoutedEventArgs e)
        {
            Start();
        }//close start

        private void LocSpecSubButton_Click(object sender, RoutedEventArgs e)
        {

            if (LocSpecInptBox.Text.ToLower().Contains("y")) 
            
            {
                player.Inventory.Add(currentItem);
                currentLocation.Items.Remove(currentItem);
            }
              LocSpecInptBox.Text = "";

            Travel();





        }
    }//closes main window
}//closes entire program

