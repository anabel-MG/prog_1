﻿using Adopt_an_Insect;
using Adopt_An_Insect;
using System;
using static System.Console;
namespace AdoptAnInsect
{
    class Program
    {
        static void Main(string[] args)
        {
         
            World myWorld = new World(); 
            myWorld.Run();

        }

    }
}