﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Adopt_an_Insect
{
    internal class InsectPet
    {
        //field
        //public=access modifier
        //string =type
        //name= identifier

        public string FullName;
        public string InsectType;
        public string food;
        //Uf= unique feature
        public string uf;
        public string color;
        public bool IsAwake;

      
        //method definition
        public void PetInfo()
        {

            WriteLine($"This  pet's name is {FullName}");
            WriteLine($" InsectType : {InsectType}");
            WriteLine($" food : {food}");
            WriteLine($" color : {color}");
            WriteLine($" unique feature : {uf}");
            WriteLine($"Is awake?{IsAwake}");
        }

        public void DoTrick()

        { WriteLine($"{FullName} is doing a trick "); }

        public void Eat()

        { WriteLine($"{FullName} is eating {food}"); }








    }

    
 



    }

