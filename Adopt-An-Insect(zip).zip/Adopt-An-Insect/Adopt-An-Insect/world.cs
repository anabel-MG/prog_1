﻿using Adopt_an_Insect;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Adopt_An_Insect
{
     class World
    {
        public void Run()
        {

            Title = " === Adopt an Insect ===";

            WriteLine(@"
   ,---.                     _,.---._        _ __   ,--.--------.           ,---.      .-._                 .=-.-..-._          ,-,--.     ,----.    _,.----.  ,--.--------.  
 .--.'  \      _,..---._   ,-.' , -  `.   .-`.' ,`./==/,  -   , -\        .--.'  \    /==/ \  .-._         /==/_ /==/ \  .-._ ,-.'-  _\ ,-.--` , \ .' .' -   \/==/,  -   , -\ 
 \==\-/\ \   /==/,   -  \ /==/_,  ,  - \ /==/, -   \==\.-.  - ,-./        \==\-/\ \   |==|, \/ /, /       |==|, ||==|, \/ /, /==/_ ,_.'|==|-  _.-`/==/  ,  ,-'\==\.-.  - ,-./ 
 /==/-|_\ |  |==|   _   _\==|   .=.     |==| _ .=. |`--`\==\- \           /==/-|_\ |  |==|-  \|  |        |==|  ||==|-  \|  |\==\  \   |==|   `.-.|==|-   |  . `--`\==\- \    
 \==\,   - \ |==|  .=.   |==|_ : ;=:  - |==| , '=',|     \==\_ \          \==\,   - \ |==| ,  | -|        |==|- ||==| ,  | -| \==\ -\ /==/_ ,    /|==|_   `-' \     \==\_ \   
 /==/ -   ,| |==|,|   | -|==| , '='     |==|-  '..'      |==|- |          /==/ -   ,| |==| -   _ |        |==| ,||==| -   _ | _\==\ ,\|==|    .-' |==|   _  , |     |==|- |   
/==/-  /\ - \|==|  '='   /\==\ -    ,_ /|==|,  |         |==|, |         /==/-  /\ - \|==|  /\ , |        |==|- ||==|  /\ , |/==/\/ _ |==|_  ,`-._\==\.       /     |==|, |   
\==\ _.\=\.-'|==|-,   _`/  '.='. -   .' /==/ - |         /==/ -/         \==\ _.\=\.-'/==/, | |- |        /==/. //==/, | |- |\==\ - , /==/ ,     / `-.`.___.-'      /==/ -/   
 `--`        `-.`.____.'     `--`--''   `--`---'         `--`--`          `--`        `--`./  `--`        `--`-` `--`./  `--` `--`---'`--`-----``                   `--`--`   
");


            WriteLine("Welcome to adopt an insect :),");
            WriteLine("(zoom out to see full title)");
            WriteLine("  "); WriteLine("  ");


            InsectPet Bee = new InsectPet();
            InsectPet Ladybug = new InsectPet();
            InsectPet Butterfly = new InsectPet();
            InsectPet Dragonfly = new InsectPet();

            Bee.FullName = "Billy";
            Bee.InsectType = "Bee";
            Bee.food = "Nectar and pollen ";
            Bee.color = "Yellow";
            Bee.uf = "Stripes";
            Bee.IsAwake = true;
            WriteLine(" >Pet 1");
            Bee.PetInfo();

            WriteLine(" ");

            Ladybug.FullName = "Lilly";
            Ladybug.InsectType = "Ladybug";
            Ladybug.food = "Small insects ";
            Ladybug.color = "Red";
            Ladybug.uf = "White dots";
            Ladybug.IsAwake = false;
            WriteLine(" >Pet 2");
            Ladybug.PetInfo();


            WriteLine(" ");

            Butterfly.FullName = "Bianca";
            Butterfly.InsectType = "Butterfly";
            Butterfly.food = "Nectar ";
            Butterfly.color = "Orange";
            Butterfly.uf = "large colorful wings";
            Butterfly.IsAwake = true;
            WriteLine(" >Pet 3");
            Butterfly.PetInfo();
            Butterfly.Eat();



            WriteLine(" ");

            Dragonfly.FullName = "Daniel";
            Dragonfly.InsectType = "Dragonfly";
            Dragonfly.food = "insects";
            Dragonfly.color = "Blue";
            Dragonfly.uf = "fast flier";
            Dragonfly.IsAwake = true;
            WriteLine(" >Pet 4");
            Dragonfly.PetInfo();
            Dragonfly.DoTrick();



        }

    }
}
