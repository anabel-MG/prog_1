﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace cumulative_verse_song
{
    public class lyrics
    {
        public int DayNum;
        public string Gift;
        int day;
        string gift;
        //constructor


        //overload constructor
        public lyrics()
        {
            

            DayNum = day;
            Gift =gift ;
            
        }

        
    }
}





