﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using static System.Console;




namespace Culmulative_verse_song
{
    internal class song
    {
        public song()
        {
            title();
        }

        public void title()
        {
            Title = "12 Days of Christmas";
            WriteLine("12 Days of Christmas");
            WriteLine(" ");
            next();
        }

        public void next()
        {
            wrtLyrc();
        }



        public void wrtLyrc()
        {
            int DayNum = 1;
            int DaysNeeded = 11;
            int DayTotal = 0;
            string suffix;
            string Gift;

            





            





            string[] gifts = {
            "a Partridge in a Pear Tree",
            "Two Turtle Doves",
            "Three French Hens",
            "Four Calling Birds",
            "Five Gold Rings",
            "Six Geese a-Laying",
            "Seven Swans a-Swimming",
            "Eight Maids a-Milking",
            "Nine Ladies Dancing",
            "Ten Lords a-Leaping",
            "Eleven Pipers Piping",
            "Twelve Drummers Drumming"
        };

            for (int day = 1; day <= 12; day++)
            {
                Console.WriteLine($"On the {GetOrdinal(day)} day of Christmas, my true love sent to me:");

                for (int i = day - 1; i >= 0; i--)
                {
                    Console.WriteLine(gifts[i]);
                }

                Console.WriteLine();
            }
        }

        static string GetOrdinal(int day)
        {


            if (day >= 11 && day <= 13)
                return $"{day}th";

            switch (day % 10)
            {
                case 1: return $"{day}st";
                case 2: return $"{day}nd";
                case 3: return $"{day}rd";
                default: return $"{day}th";
            }
        }
    }


}
  





















