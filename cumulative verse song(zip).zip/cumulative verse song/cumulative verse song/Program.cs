﻿



namespace Culmulative_verse_song
{

    class Program
    {
        static void Main()
        {
            new song();
        }
    }
}